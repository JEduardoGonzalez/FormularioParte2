document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("formulario");
    const mensajeError= document.getElementById("mensajeError");
    const NoError= document.getElementById("NoError");


    formulario.addEventListener("submit", function (event) {
        var Errors = false;
        event.preventDefault();
        mensajeError.innerHTML = "";
        NoError.innerHTML = "";

        // Obtener los valores de los campos
        const id = formulario.id.value;
        const nombre = formulario.nombre.value;
        const apellidos = formulario.apellidos.value;
        const telefono = formulario.telefono.value;
        const correo = formulario.correo.value;
        const edad = formulario.edad.value;
        const fechaNacimiento = formulario.fechaNacimiento.value;


        // Validar ID (5 dígitos exactos)
        if (!/^\d{5}$/.test(id)) {
            mensajeError.innerHTML += "El ID debe tener 5 dígitos exactos.<br>";
            var Errors = true;
        }


        // Validar nombre y apellidos (no pueden estar vacíos)
        if (nombre.trim() === "" || apellidos.trim() === "") {
            mensajeError.innerHTML += "El nombre y los apellidos no pueden estar vacíos.<br>";
            var Errors = true;
        }


        // Validar teléfono (###)###-####
        if (!/^[(]{1}\d{3}[)]{1}\d{3}-\d{4}$/.test(telefono)) {
            mensajeError.innerHTML += "El teléfono debe tener el formato (###)###-####.<br>";
            var Errors = true;
        }


        // Validar correo electrónico
        if (!/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(correo)) {
            mensajeError.innerHTML += "El correo electrónico no es válido.<br>";
            var Errors = true;
        }


        // Validar edad (número positivo)
        const edadNum = parseInt(edad);
        if (isNaN(edadNum) || edadNum <= 0) {
            mensajeError.innerHTML += "La edad debe ser un número positivo.<br>";
            var Errors = true;
        }


        // Validar fecha de nacimiento (AAAA-MM-DD)
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fechaNacimiento)) {
            mensajeError.innerHTML += "La fecha de nacimiento debe tener el formato AAAA-MM-DD.<br>";
            var Errors = true;
        }

        if(Errors==false){
            // Si todas las validaciones pasaron, puedes enviar el formulario o realizar otras acciones aquí
            NoError.innerHTML = "Formulario enviado con éxito.";
            }
            
    });
});
