// scriptResultados.js (en la página "resultados.html")
document.addEventListener("DOMContentLoaded", function() {
    const tablaResultados = document.getElementById("tablaResultados");
      // Obtener los envíos almacenados en el almacenamiento local
    const envios = JSON.parse(localStorage.getItem("envios")) || [];
     // Recorrer los envíos y agregar filas a la tabla
    envios.forEach((envio) => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${envio.id}</td>
            <td>${envio.nombre}</td>
            <td>${envio.apellidos}</td>
            <td>${envio.telefono}</td>
            <td>${envio.correo}</td>
            <td>${envio.edad}</td>
            <td>${envio.fechaNacimiento}</td>
        `;
        tablaResultados.appendChild(fila);
    });
    });
    document.addEventListener("DOMContentLoaded", function () {
        const $tablaResultados = document.getElementById("tablaResultados");
        limpiar.addEventListener("click", function (event) {
            event.preventDefault();
            tablaResultados.remove();
            localStorage.removeItem("envios");
        });
    });
    document.addEventListener("DOMContentLoaded", function () {
        volver.addEventListener("click", function (event) {
            event.preventDefault();
            window.history.back();
        });
    });
    document.addEventListener("DOMContentLoaded", function() {
        const borrar = document.getElementById("borrar");
        const tablaResultados = document.getElementById("tablaResultados");
        borrar.addEventListener("click", function() {
            const idAEliminar = prompt("Escriba el ID del elemento a eliminar:");
            if (idAEliminar !== null) {
                // Buscar la fila que contiene el ID a eliminar
                const filas = tablaResultados.getElementsByTagName("tr");
                for (let i = 0; i < filas.length; i++) {
                    const fila = filas[i];
                    const idFila = fila.getElementsByTagName("td")[0].textContent; // Suponiendo que el ID está en la primera columna (td)
                    if (idFila === idAEliminar) {
                        tablaResultados.deleteRow(i);
                        // También puedes eliminar los datos del almacenamiento local
                        eliminarDatosLocalStorage(idAEliminar);
                        break; // Salir del bucle una vez que se encuentra y elimina la fila
                    }
                }
            }
        });
        // Función para eliminar datos del almacenamiento local
        function eliminarDatosLocalStorage(id) {
            const envios = JSON.parse(localStorage.getItem("envios")) || [];
            const nuevosEnvios = envios.filter((envio) => envio.id !== id);
            localStorage.setItem("envios", JSON.stringify(nuevosEnvios));
        }
    });